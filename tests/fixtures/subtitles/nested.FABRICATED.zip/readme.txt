the subtitles are in subs.zip
